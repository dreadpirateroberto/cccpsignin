#/bin/sh
java -jar ccctsignin1_7.jar
