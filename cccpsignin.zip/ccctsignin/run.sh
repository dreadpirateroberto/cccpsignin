#/bin/sh
java -jar ccctsignin.jar
